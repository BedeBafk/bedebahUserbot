__MODULE__ = "ʟᴇᴀᴠᴇ ɢʟɪᴍɪᴛ"
__HELP__ = """
<b>✭ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʟᴇᴀᴠᴇ ɢʟɪᴍɪᴛ ✭</b>

<blockquote><b>✭ perintah : 
<code>{0}leaveallmute</code>
Untuk keluar dari grub yang membatasi anda</b></blockquote>
"""
