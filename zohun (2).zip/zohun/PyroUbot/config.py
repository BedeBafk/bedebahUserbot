import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "100"))

DEVS = list(map(int, os.getenv("DEVS", "13018689").split()))

API_ID = int(os.getenv("API_ID", "293376"))

API_HASH = os.getenv("API_HASH", "5a159dde6013b22490f29fbae4c679")

BOT_TOKEN = os.getenv("BOT_TOKEN", "7787478650:AAEMbfgRWz0xRxYaJ6WlSnADlBfg9L01M")

OWNER_ID = int(os.getenv("OWNER_ID", "1301819689"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-10025489026").split()))

RMBG_API = os.getenv("RMBG_API", "mBV2sE7h74P3cu4Rdv5wKs")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://zohunubot:abcdefg@zohunu.kci0rqz.mongodb.net/?retryWrites=true&w=majority&appName=Zohun")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002548026"))
